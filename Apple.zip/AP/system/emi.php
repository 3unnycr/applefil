<?php

$src="../Email";
header("location:$src");