<?php 

$websit = "https://api.telegram.org/bot5836766373:AAG8OoIFmNp5RaxknZeIg3aMLzG8LkZfd_k";
$param = ['chat_id' => '-810405947', 'text' => $yagmai, ];
$ch = curl_init($websit . '/sendMessage');
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, ($param));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$result = curl_exec($ch);
curl_close($ch);